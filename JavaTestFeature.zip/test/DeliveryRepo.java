package com.hlag.test;

import java.util.List;
import java.util.Optional;

public interface DeliveryRepo {

	void save(Delivery delivery);

	Optional<Delivery> findById(String deliveryId);

	List<Delivery> findAll();

	void update(Delivery delivery);

	void deleteById(String deliveryId);

	List<Delivery> findCompletedDeliveries();

	List<Delivery> findRevenueExceeds50();

	List<Delivery> modifiedDeliveriescoBympletedAsDeliveryId(String Id);

	void removeDeliveriesByCompletedAsDelivery();

	double calculateTotalRevenue();

	double calculateavarageDeliveryTime();

}
