package com.hlag.test;

import java.util.stream.IntStream;

public class ThreadDemo {

	public static void main(String arg[]) {
		Runnable runnable = () -> {

			IntStream.range(1, 2).forEach((e)->{
				try {
					Thread.sleep(1000);
					System.out.println(e + Thread.currentThread().getName());
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
				}
			
            });
		};
		Thread thread = new Thread(runnable);
		try {
			thread.join();
			thread.setPriority(8);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		thread.start();
		Thread thread2 = new Thread(runnable);
		try {
			thread2.join();
			thread2.setPriority(9);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		thread2.start();
		Thread thread3 = new Thread(runnable);
		try {
			thread3.join();
			thread3.setPriority(7);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}}

