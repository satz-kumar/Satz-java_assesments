package com.hlag.test;


public class product {

	String name;
	double price;

	public product(String name, double price) {
		this.name = name;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}


}
