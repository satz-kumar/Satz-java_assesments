package com.hlag.test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CustomCollectors {

	public static void main(String[] args) {
		List<product> products = Arrays
				.asList(new product("apple", 1.0), new product("banana", 2.0), new product("orange", 3.0));

		Map<String, Double> productPriceMap = products.stream().collect(Collectors.groupingBy(p -> {
			if (p.getPrice() < 2) {
				return "<2";
			} else if (p.getPrice() < 3) {
				return "2-3";
			} else {
				return ">=3";
			}
		}, Collector.of(() -> new double[0], (a, p) -> a[0] += p.getPrice(), (a1, a2) -> {
			a1[0] += a2[0];
			return a1;
		}, a -> a[0])));

		productPriceMap.forEach((k, v) -> System.out.println(k + " : " + v));

		System.out.println("Total value by price range: " + productPriceMap);

	}
}
