package com.hlag.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.hlag.exception.InvalidProductDataException;

public class DeliveryRepoImpl implements DeliveryRepo {

	private List<Delivery> deliveries = new ArrayList<>();

	@Override
	public void save(Delivery delivery) {
		// TODO Auto-generated method stub
		deliveries.add(delivery);
	}

	@Override
	public Optional<Delivery> findById(String deliveryId) {
		// TODO Auto-generated method stub
		return deliveries.stream().filter(delivery -> delivery.getDeliveryId().equals(deliveryId)).findFirst();
	}

	@Override
	public List<Delivery> findAll() {
		// TODO Auto-generated method stub
		return new ArrayList<>(deliveries);
	}

	// Update an existing delivery
	@Override
	public void update(Delivery delivery) {
		Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
		if (existingDelivery.isPresent()) {
			deliveries.remove(existingDelivery.get());
			deliveries.add(delivery);
		}
	}

	// Delete a delivery by its ID
	@Override
	public void deleteById(String deliveryId) {
		deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
	}

	// Get deliveries that are completed
	@Override
	public List<Delivery> findCompletedDeliveries() {
		List<Delivery> completedDeliveries = new ArrayList<>();
//		for (Delivery delivery : deliveries) {
//			if (delivery.isCompleted()) {
//				completedDeliveries.add(delivery);
//			}
//		}
return completedDeliveries.parallelStream().filter(Delivery::isCompleted).collect(Collectors.toList());

	}

	@Override
	public List<Delivery> findRevenueExceeds50() {
		List<Delivery> completedDeliveries = new ArrayList<>();
		return completedDeliveries.stream().filter(delivery -> delivery.getRevenue() > 50).collect(Collectors.toList());
	}

	@Override
	public List<Delivery> modifiedDeliveriescoBympletedAsDeliveryId(String Id) {
		// TODO Auto-generated method stub
		List<Delivery> completedDeliveries = new ArrayList<>();
		// return completedDeliveries.parallelStream().map(delivery -> {
		// if (delivery.isCompleted()) {
		// delivery.setDeliveryId(delivery.getDeliveryId());
		// }
		// return delivery;
		// }).collect(Collectors.toList());

		List<Delivery> del = deliveries.parallelStream()
				.filter(e -> !e.isCompleted() && e.getDeliveryId().equals(Id))
				.map(a -> {
			a.setCompleted(true);
			return a;
		}) // Modify and return the object
				.collect(Collectors.toList());

		return completedDeliveries.parallelStream().filter(Delivery::isCompleted).map(delivery -> {
			delivery.setDeliveryId(delivery.getDeliveryId());
			return delivery;
		}).collect(Collectors.toList());
	}

	@Override
	public void removeDeliveriesByCompletedAsDelivery() {
		// TODO Auto-generated method stub
		List<Delivery> completedDeliveries = new ArrayList<>();
		// return completedDeliveries.parallelStream().filter(delivery ->
		// !delivery.isCompleted()).collect(Collectors.toList());
		completedDeliveries.removeIf(d -> d.isCompleted());
	}

	@Override
	public double calculateTotalRevenue() {
		return deliveries.parallelStream().mapToDouble(Delivery::getRevenue).sum();
	}

	@Override
	public double calculateavarageDeliveryTime() {
		// TODO Auto-generated method stub
		return deliveries.stream().mapToDouble(Delivery::getDoubledeliveryTimeInHours).average().getAsDouble();
	}

	public double calculateRevenueToTimeRatio() throws InvalidProductDataException {
		return deliveries.parallelStream()
				.mapToDouble(e->e.getDoubledeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new InvalidProductDataException("No deliveries found"));
			//	.getAsDouble();
	}
	
	public List<Delivery> findTopKPerformingDeliveries(int k) {
		return deliveries.parallelStream()
				.filter(e -> e.isCompleted())
                .sorted((d1, d2) -> Double.compare(d2.getDoubledeliveryTimeInHours(), d1.getDoubledeliveryTimeInHours())).toList();
                //Double.compare(d2.getDoubledeliveryTimeInHours(), d1.getDoubledeliveryTimeInHours())).limit(k).toList();
    }
	}
	

