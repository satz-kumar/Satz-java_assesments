package com.halg.shippingmanagementsystem.entity;

public class Shipment {
 
	private Long id;
	private Order order;
	private String trackingNumber;
	private String assignedDriver;
 
	public Long getId() {
		return id;
	}
 
	public void setId(Long id) {
		this.id = id;
	}
 
	public Order getOrder() {
		return order;
	}
 
	public void setOrder(Order order) {
		this.order = order;
	}
 
	public String getTrackingNumber() {
		return trackingNumber;
	}
 
	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}
 
	public String getAssignedDriver() {
		return assignedDriver;
	}
 
	public void setAssignedDriver(String assignedDriver) {
		this.assignedDriver = assignedDriver;
	}
 
	public Shipment(Long id, Order order, String trackingNumber, String assignedDriver) {
		super();
		this.id = id;
		this.order = order;
		this.trackingNumber = trackingNumber;
		this.assignedDriver = assignedDriver;
	}
 
	public Shipment() {
		super();
	}
 
	@Override
	public String toString() {
		return "Shipment [id=" + id + ", order=" + order + ", trackingNumber=" + trackingNumber + ", assignedDriver="
				+ assignedDriver + "]";
	}
}
 