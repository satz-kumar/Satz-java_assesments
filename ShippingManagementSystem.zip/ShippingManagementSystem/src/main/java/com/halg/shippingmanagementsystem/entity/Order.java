package com.halg.shippingmanagementsystem.entity;


public class Order {

	private Long id;
	private User customer;
	private String destination;
	private Double weight;
	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getCustomer() {
		return customer;
	}

	public void setCustomer(User customer) {
		this.customer = customer;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Order(Long id, User customer, String destination, Double weight, String status) {
		super();
		this.id = id;
		this.customer = customer;
		this.destination = destination;
		this.weight = weight;
		this.status = status;
	}

	public Order() {
		super();
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", customer=" + customer + ", destination=" + destination + ", weight=" + weight
				+ ", status=" + status + "]";
	}
}
