package com.halg.shippingmanagementsystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Shipment;
import com.hlag.exception.InvalidProductDataException;

public class ShipmentServiceImpl implements ShipmentService {

	@Override
	public Shipment addProduct(Shipment shipment) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Shipment> getByProductId(UUID shipmentID) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Shipment updateOrderById(UUID shipmentID, Shipment shipment) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteOrder(UUID shipmentID) throws InvalidProductDataException {
		// TODO Auto-generated method stub

	}

}
