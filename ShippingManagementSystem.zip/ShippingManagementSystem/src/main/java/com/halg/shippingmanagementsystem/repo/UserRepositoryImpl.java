package com.halg.shippingmanagementsystem.repo;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.User;
import com.hlag.exception.InvalidProductDataException;

public class UserRepositoryImpl implements UserRepository {
    private static UserRepositoryImpl instance;
		List<User> users = new ArrayList<>();
    private UserRepositoryImpl() {} // Private constructor

    public static synchronized UserRepositoryImpl getInstance() {
        if (instance == null) {
            instance = new UserRepositoryImpl();
        }
        return instance;
    }

		@Override
		public User addProduct(User user) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Optional<User> getByProductId(UUID userID) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return Optional.empty();
		}

		@Override
		public User updateUserById(UUID userID, User user) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void deleteUser(UUID userID) throws InvalidProductDataException {
			// TODO Auto-generated method stub

		}

}
