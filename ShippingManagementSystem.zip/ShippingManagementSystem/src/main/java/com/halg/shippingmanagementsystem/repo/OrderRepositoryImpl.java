package com.halg.shippingmanagementsystem.repo;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Order;
import com.hlag.exception.InvalidProductDataException;

public class OrderRepositoryImpl implements OrderRepository {
    private static OrderRepositoryImpl instance;
		// Simulates order data storage
		List<Order> orders = new ArrayList<>();

    private OrderRepositoryImpl() {} // Private constructor

    public static synchronized OrderRepositoryImpl getInstance() {
        if (instance == null) {
            instance = new OrderRepositoryImpl();
        }
        return instance;
    }

		@Override
		public Order addProduct(Order order) throws InvalidProductDataException {
			return orders.add(order) ? order : null;
		}

		@Override
		public Optional<Order> getByProductId(UUID orderID) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return Optional.empty();
		}

		@Override
		public Order updateOrderById(UUID orderID, Order order) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void deleteOrder(UUID orderID) throws InvalidProductDataException {
			// TODO Auto-generated method stub

		}

}
