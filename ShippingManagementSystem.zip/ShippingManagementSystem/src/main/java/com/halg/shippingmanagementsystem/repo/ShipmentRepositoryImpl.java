package com.halg.shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Shipment;
import com.hlag.exception.InvalidProductDataException;

public class ShipmentRepositoryImpl implements ShipmentRepository {
    private static ShipmentRepositoryImpl instance;
		List<Shipment> shipments = new ArrayList<>();
    private ShipmentRepositoryImpl() {} // Private constructor

    public static synchronized ShipmentRepositoryImpl getInstance() {
        if (instance == null) {
            instance = new ShipmentRepositoryImpl();
        }
        return instance;
    }

		@Override
		public Shipment addProduct(Shipment shipment) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Optional<Shipment> getByProductId(UUID shipmentID) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return Optional.empty();
		}

		@Override
		public Shipment updateOrderById(UUID shipmentID, Shipment shipment) throws InvalidProductDataException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void deleteOrder(UUID shipmentID) throws InvalidProductDataException {
			// TODO Auto-generated method stub

		}

}
