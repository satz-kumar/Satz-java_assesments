package com.halg.shippingmanagementsystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Shipment;
import com.hlag.exception.InvalidProductDataException;

public interface ShipmentService {

	public Shipment addProduct(Shipment shipment) throws InvalidProductDataException;

	public Optional<Shipment> getByProductId(UUID shipmentID) throws InvalidProductDataException;

	public Shipment updateOrderById(UUID shipmentID, Shipment shipment) throws InvalidProductDataException;

	public void deleteOrder(UUID shipmentID) throws InvalidProductDataException;
}
