package com.halg.shippingmanagementsystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Order;
import com.hlag.exception.InvalidProductDataException;

public interface OrderService {

	public Order addProduct(Order order) throws InvalidProductDataException;

	public Optional<Order> getByProductId(UUID orderID) throws InvalidProductDataException;

	public Order updateOrderById(UUID orderID, Order order) throws InvalidProductDataException;

	public void deleteOrder(UUID orderID) throws InvalidProductDataException;
}
