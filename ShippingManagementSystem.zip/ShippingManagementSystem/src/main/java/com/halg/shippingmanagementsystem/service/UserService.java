package com.halg.shippingmanagementsystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.User;
import com.hlag.exception.InvalidProductDataException;

public interface UserService {

	public User addProduct(User user) throws InvalidProductDataException;

	public Optional<User> getByProductId(UUID userID) throws InvalidProductDataException;

	public User updateUserById(UUID userID, User user) throws InvalidProductDataException;

	public void deleteUser(UUID userID) throws InvalidProductDataException;
}
