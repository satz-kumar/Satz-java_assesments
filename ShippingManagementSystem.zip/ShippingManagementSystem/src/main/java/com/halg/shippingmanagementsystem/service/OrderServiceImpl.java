package com.halg.shippingmanagementsystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.shippingmanagementsystem.entity.Order;
import com.hlag.exception.InvalidProductDataException;

public class OrderServiceImpl implements OrderService {

	@Override
	public Order addProduct(Order order) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Order> getByProductId(UUID orderID) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Order updateOrderById(UUID orderID, Order order) throws InvalidProductDataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteOrder(UUID orderID) throws InvalidProductDataException {
		// TODO Auto-generated method stub

	}

}
