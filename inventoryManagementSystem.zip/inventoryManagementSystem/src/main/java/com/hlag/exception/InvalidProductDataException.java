package com.hlag.exception;


public class InvalidProductDataException extends Exception {

	public InvalidProductDataException(String message) {
		super(message);
	}
}
