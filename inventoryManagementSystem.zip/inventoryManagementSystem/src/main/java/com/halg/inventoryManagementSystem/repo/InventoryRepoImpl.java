package com.halg.inventoryManagementSystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.halg.inventoryManagementSystem.entity.Product;
import com.hlag.exception.InvalidProductDataException;

public class InventoryRepoImpl implements InventoryRepo {

	private static InventoryRepoImpl inventoryRepoImpl;
	private List<Product> products = new ArrayList<>();

	private InventoryRepoImpl() {
	}

	public static InventoryRepoImpl getInstance() {
		if (inventoryRepoImpl == null) {
			inventoryRepoImpl = new InventoryRepoImpl();
		}
		return inventoryRepoImpl;

	}

	@Override
	public Product addProduct(Product product) throws InvalidProductDataException {
		validateProductData(product);
		products.add(product);
		return product;
	}

	private void validateProductData(Product product) throws InvalidProductDataException {
		if (product.getPrice() < 0) {
			throw new InvalidProductDataException("Price cannot be negative.");
		}
		if (product.getQuantity() < 0) {
			throw new InvalidProductDataException("Quantity cannot be negative.");
		}
	}

	@Override
	public Optional<Product> getByProductId(UUID productID) throws InvalidProductDataException {
		Optional<Product> productOpt = products.stream()
				.filter(product -> product.getProductID().equals(productID))
				.findFirst();

		if (productOpt.isEmpty()) {
			throw new InvalidProductDataException("Product with ID " + productID + " not found.");
		}

		return productOpt;
	}

	@Override
	public Product updateProductById(UUID productID, Product newProduct) throws InvalidProductDataException {
		Optional<Product> productOpt = products.stream()
        .filter(product -> product.getProductID().equals(productID))
        .findFirst();
if (productOpt.isPresent()) {
    Product existingProduct = productOpt.get();
		int index = products.indexOf(existingProduct);
		products.set(index, newProduct);
    return newProduct;
} else {
	throw new InvalidProductDataException("Product with ID " + productID + " not found.");
}
}

@Override
public void deleteProduct(UUID productID) throws InvalidProductDataException {
	Product product = getByProductId(productID)
			.orElseThrow(() -> new InvalidProductDataException("Product with ID " + productID + " not found."));
	products.remove(product);
}

}
