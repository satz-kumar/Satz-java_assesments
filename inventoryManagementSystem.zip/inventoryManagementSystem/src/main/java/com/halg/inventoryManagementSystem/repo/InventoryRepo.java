package com.halg.inventoryManagementSystem.repo;

import java.util.Optional;
import java.util.UUID;

import com.halg.inventoryManagementSystem.entity.Product;
import com.hlag.exception.InvalidProductDataException;

public interface InventoryRepo {

	public Product addProduct(Product product) throws InvalidProductDataException;
	 
	public Optional<Product> getByProductId(UUID productID) throws InvalidProductDataException;
	 
		public Product updateProductById(UUID productID, Product product) throws InvalidProductDataException;

		public void deleteProduct(UUID productID) throws InvalidProductDataException;
}
