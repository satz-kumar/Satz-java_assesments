package com.halg.inventoryManagementSystem.service;

import java.util.Optional;
import java.util.UUID;

import com.halg.inventoryManagementSystem.entity.Product;
import com.halg.inventoryManagementSystem.repo.InventoryRepo;
import com.halg.inventoryManagementSystem.repo.InventoryRepoImpl;
import com.hlag.exception.InvalidProductDataException;

public class InventoryServiceImpl implements InventoryService {

	private static InventoryServiceImpl inventoryServiceImpl;
	private InventoryRepo userRepository = InventoryRepoImpl.getInstance();

	public static InventoryServiceImpl getInstance() {
		if (inventoryServiceImpl == null) {
			inventoryServiceImpl = new InventoryServiceImpl();
		}
		return inventoryServiceImpl;

	}

	@Override
	public Product addProduct(Product product) throws InvalidProductDataException {
		return userRepository.addProduct(product);
	}

	@Override
	public Optional<Product> getByProductId(UUID productID) throws InvalidProductDataException {
		return userRepository.getByProductId(productID);
	}

	@Override
	public Product updateProductById(UUID productID, Product product) throws InvalidProductDataException {
		return userRepository.updateProductById(productID, product);
	}

	@Override
	public void deleteProduct(UUID productID) throws InvalidProductDataException {
		userRepository.deleteProduct(productID);
	}

}
