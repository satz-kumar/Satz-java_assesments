package com.halg.inventoryManagementSystem.entity;

import java.util.UUID;

import com.hlag.exception.InvalidProductDataException;

public class Product {

	private UUID productID;
	private String name;
	private String description;
	private double price;
	private int quantity;

	public Product(String name, String description, double price, int quantity) {
		this.productID = UUID.randomUUID();
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}

	public UUID getProductID() {
		return productID;
	}

	public void setProductID(UUID productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) throws InvalidProductDataException {
		if (price >= 0) {
			this.price = price;
		} else {
			throw new InvalidProductDataException("Price cannot be negative.");
		}
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) throws InvalidProductDataException {
		if (quantity >= 0) {
			this.quantity = quantity;
		} else {
			throw new InvalidProductDataException("Quantity cannot be negative.");
	}
}
}
